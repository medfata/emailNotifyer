"""Exposes version constant to avoid circular dependencies."""

VERSION = "2.28.1"
